import React from 'react'

const BoutonNavigationComponent = () => (
    <div className='' />

)

export default BoutonNavigationComponent
