import React from 'react'

const PlayVideoComponent = () => (
    <div className='' />

)

export default PlayVideoComponent
