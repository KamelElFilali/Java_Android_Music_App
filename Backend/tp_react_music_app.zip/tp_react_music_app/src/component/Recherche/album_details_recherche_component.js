import React from 'react'

const AlbumDetailsRechercheComponent = () => (
    <div className=''>
        <h1>RECHERCHE</h1>
    </div>

)

export default AlbumDetailsRechercheComponent
